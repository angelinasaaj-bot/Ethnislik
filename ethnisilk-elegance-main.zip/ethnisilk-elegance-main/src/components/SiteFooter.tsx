import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="bg-[oklch(0.22_0.04_25)] text-[oklch(0.92_0.02_60)]">
      <div className="container mx-auto px-4 py-16 grid gap-10 md:grid-cols-4">
        <div>
          <h3 className="font-serif text-3xl text-accent">EthniSilk</h3>
          <p className="mt-4 text-sm text-white/70 leading-relaxed">
            Weaving timeless tradition into every thread. Discover handcrafted sarees,
            lehengas and bridal wear made for life's most romantic stories.
          </p>
          <div className="mt-5 flex gap-3">
            <a href="#" aria-label="Instagram" className="rounded-full border border-white/20 p-2 hover:bg-accent hover:text-accent-foreground hover:border-accent transition">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" aria-label="Facebook" className="rounded-full border border-white/20 p-2 hover:bg-accent hover:text-accent-foreground hover:border-accent transition">
              <Facebook className="h-4 w-4" />
            </a>
            <a href="#" aria-label="Twitter" className="rounded-full border border-white/20 p-2 hover:bg-accent hover:text-accent-foreground hover:border-accent transition">
              <Twitter className="h-4 w-4" />
            </a>
            <a href="#" aria-label="YouTube" className="rounded-full border border-white/20 p-2 hover:bg-accent hover:text-accent-foreground hover:border-accent transition">
              <Youtube className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-serif text-lg text-white">Shop</h4>
          <ul className="mt-4 space-y-2 text-sm text-white/70">
            <li><Link to="/" className="hover:text-accent transition">Wedding Saree</Link></li>
            <li><Link to="/" className="hover:text-accent transition">Silk Choli</Link></li>
            <li><Link to="/" className="hover:text-accent transition">Embroidered Lehenga</Link></li>
            <li><Link to="/" className="hover:text-accent transition">Bridal Collection</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-serif text-lg text-white">Customer Care</h4>
          <ul className="mt-4 space-y-2 text-sm text-white/70">
            <li><a href="#" className="hover:text-accent transition">Contact Us</a></li>
            <li><a href="#" className="hover:text-accent transition">Shipping & Returns</a></li>
            <li><a href="#" className="hover:text-accent transition">Size Guide</a></li>
            <li><a href="#" className="hover:text-accent transition">FAQs</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-serif text-lg text-white">Newsletter</h4>
          <p className="mt-4 text-sm text-white/70">
            Sign up for new arrivals, private sales and styling stories.
          </p>
          <form className="mt-4 flex" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              required
              placeholder="Your email"
              className="flex-1 rounded-l-md bg-white/10 text-white placeholder:text-white/50 px-3 py-2 text-sm outline-none border border-white/15 focus:border-accent"
            />
            <button
              type="submit"
              className="rounded-r-md bg-accent text-accent-foreground px-4 text-sm font-medium hover:opacity-90"
            >
              Join
            </button>
          </form>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-5 text-center text-xs text-white/60">
          © {new Date().getFullYear()} EthniSilk. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
