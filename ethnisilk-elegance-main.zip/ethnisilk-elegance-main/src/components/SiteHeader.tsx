import { Link } from "@tanstack/react-router";
import { Search, User, Heart, Phone, Mail } from "lucide-react";
import { CartDrawer } from "@/components/CartDrawer";

export function SiteHeader() {
  return (
    <header className="w-full">
      {/* Top utility bar */}
      <div className="bg-primary text-primary-foreground text-xs">
        <div className="container mx-auto flex items-center justify-between px-4 py-2">
          <div className="hidden md:flex items-center gap-4 opacity-90">
            <span className="flex items-center gap-1.5">
              <Phone className="h-3 w-3" /> +91 98765 43210
            </span>
            <span className="flex items-center gap-1.5">
              <Mail className="h-3 w-3" /> hello@ethnisilk.com
            </span>
          </div>
          <div className="md:hidden text-xs">Free shipping on orders above ₹2999</div>
          <div className="hidden md:block opacity-90">
            Crafted in India • Worldwide Delivery
          </div>
        </div>
      </div>

      {/* Main nav */}
      <div className="bg-background border-b border-border">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <Link to="/" className="font-serif text-3xl font-semibold text-primary tracking-tight">
            EthniSilk
          </Link>

          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-foreground">
            <Link to="/" className="hover:text-primary transition">Home</Link>
            <Link to="/" hash="collections" className="hover:text-primary transition">Collections</Link>
            <Link to="/" hash="sarees" className="hover:text-primary transition">Sarees</Link>
            <Link to="/" hash="lehenga" className="hover:text-primary transition">Lehenga</Link>
            <Link to="/" hash="bridal" className="hover:text-primary transition">Bridal</Link>
            <Link to="/" hash="about" className="hover:text-primary transition">About</Link>
          </nav>

          <div className="flex items-center gap-1">
            <button className="p-2 hover:text-primary transition" aria-label="Search">
              <Search className="h-5 w-5" />
            </button>
            <button className="p-2 hover:text-primary transition hidden sm:block" aria-label="Account">
              <User className="h-5 w-5" />
            </button>
            <button className="p-2 hover:text-primary transition hidden sm:block" aria-label="Wishlist">
              <Heart className="h-5 w-5" />
            </button>
            <div className="bg-primary rounded-full ml-1">
              <CartDrawer />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
