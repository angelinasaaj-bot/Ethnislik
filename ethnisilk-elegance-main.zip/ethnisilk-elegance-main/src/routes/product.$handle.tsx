import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { fetchProductByHandle, formatPrice } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";
import { ChevronLeft, Loader2, ShoppingBag } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/product/$handle")({
  component: ProductPage,
  errorComponent: ({ error, reset }) => {
    const router = useRouter();
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center max-w-md">
          <h1 className="font-serif text-2xl">Something went wrong</h1>
          <p className="text-sm text-muted-foreground mt-2">{error.message}</p>
          <Button
            className="mt-4"
            onClick={() => {
              router.invalidate();
              reset();
            }}
          >
            Try again
          </Button>
        </div>
      </div>
    );
  },
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="font-serif text-3xl">Product not found</h1>
        <Link to="/" className="text-primary underline mt-4 inline-block">
          Back to home
        </Link>
      </div>
    </div>
  ),
});

function ProductPage() {
  const { handle } = Route.useParams();
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);
  const [variantId, setVariantId] = useState<string | null>(null);
  const [activeImage, setActiveImage] = useState(0);

  const { data: product, isLoading: loading } = useQuery({
    queryKey: ["product", handle],
    queryFn: () => fetchProductByHandle(handle),
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <SiteHeader />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-serif text-3xl">Product not found</h1>
            <Link to="/" className="text-primary underline mt-4 inline-block">
              Back to home
            </Link>
          </div>
        </main>
        <SiteFooter />
      </div>
    );
  }

  const images = product.images.edges;
  const variants = product.variants.edges;
  const selectedVariant =
    variants.find((v: any) => v.node.id === variantId)?.node || variants[0]?.node;

  const handleAdd = async () => {
    if (!selectedVariant) return;
    await addItem({
      product: { node: product },
      variantId: selectedVariant.id,
      variantTitle: selectedVariant.title,
      price: selectedVariant.price,
      quantity: 1,
      selectedOptions: selectedVariant.selectedOptions || [],
    });
    toast.success("Added to bag", {
      description: product.title,
      position: "top-center",
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SiteHeader />
      <main className="container mx-auto px-4 py-8 flex-1">
        <Link to="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-6">
          <ChevronLeft className="h-4 w-4 mr-1" /> Back
        </Link>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div>
            <div className="aspect-[3/4] rounded-md overflow-hidden bg-secondary/30">
              {images[activeImage] ? (
                <img
                  src={images[activeImage].node.url}
                  alt={images[activeImage].node.altText || product.title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center text-muted-foreground">
                  No image
                </div>
              )}
            </div>
            {images.length > 1 && (
              <div className="mt-4 grid grid-cols-5 gap-2">
                {images.map((img: any, i: number) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`aspect-square rounded overflow-hidden border-2 ${i === activeImage ? "border-primary" : "border-transparent"}`}
                  >
                    <img src={img.node.url} alt="" className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <h1 className="font-serif text-4xl text-foreground">{product.title}</h1>
            <p className="mt-3 text-2xl text-primary font-medium">
              {formatPrice(
                selectedVariant?.price.amount ?? product.priceRange.minVariantPrice.amount,
                selectedVariant?.price.currencyCode ?? product.priceRange.minVariantPrice.currencyCode,
              )}
            </p>
            {product.description && (
              <p className="mt-6 text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                {product.description}
              </p>
            )}

            {product.options.length > 0 && variants.length > 1 && (
              <div className="mt-6 space-y-4">
                {product.options.map((opt: any) => (
                  <div key={opt.name}>
                    <div className="text-sm font-medium mb-2">{opt.name}</div>
                    <div className="flex flex-wrap gap-2">
                      {opt.values.map((val: string) => {
                        const match = variants.find((v: any) =>
                          v.node.selectedOptions.some(
                            (so: any) => so.name === opt.name && so.value === val,
                          ),
                        );
                        const active = selectedVariant?.selectedOptions.some(
                          (so: any) => so.name === opt.name && so.value === val,
                        );
                        return (
                          <button
                            key={val}
                            onClick={() => match && setVariantId(match.node.id)}
                            className={`px-4 py-2 rounded border text-sm transition ${
                              active
                                ? "border-primary bg-primary text-primary-foreground"
                                : "border-border hover:border-primary"
                            }`}
                          >
                            {val}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <Button
              onClick={handleAdd}
              disabled={isLoading || !selectedVariant?.availableForSale}
              className="mt-8 w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              size="lg"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <ShoppingBag className="h-4 w-4 mr-2" />
                  {selectedVariant?.availableForSale ? "Add to Bag" : "Sold Out"}
                </>
              )}
            </Button>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
