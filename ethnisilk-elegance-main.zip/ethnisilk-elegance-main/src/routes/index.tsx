import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ProductCard } from "@/components/ProductCard";
import { fetchProducts } from "@/lib/shopify";
import { ChevronRight, Sparkles, Truck, ShieldCheck, RotateCcw } from "lucide-react";

import heroBride from "@/assets/hero-bride.jpg";
import bannerCouple from "@/assets/banner-couple.jpg";
import catSaree from "@/assets/cat-saree.jpg";
import catCholi from "@/assets/cat-choli.jpg";
import catLehenga from "@/assets/cat-lehenga.jpg";
import catBridal from "@/assets/cat-bridal.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "EthniSilk — Handcrafted Sarees, Lehengas & Bridal Wear" },
      {
        name: "description",
        content:
          "Gorgeous designs that perfectly express your romantic stories. Shop wedding sarees, silk cholis, embroidered lehengas and bridal collections at EthniSilk.",
      },
      { property: "og:title", content: "EthniSilk — Timeless Indian Ethnic Wear" },
      {
        property: "og:description",
        content:
          "Discover handcrafted sarees, lehengas and bridal couture from EthniSilk.",
      },
      { property: "og:image", content: heroBride },
    ],
  }),
  component: HomePage,
});

const categories = [
  "Wedding Saree",
  "Silk Choli",
  "Embroidered Lehenga",
  "Lehenga",
  "Engagement Lehenga",
  "Embroidery Saree",
];

function HomePage() {
  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: () => fetchProducts(12),
  });

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SiteHeader />

      {/* HERO */}
      <section className="relative">
        <div className="relative h-[560px] md:h-[640px] w-full overflow-hidden">
          <img
            src={heroBride}
            alt="EthniSilk bride in maroon bridal saree"
            width={1920}
            height={1080}
            className="absolute inset-0 h-full w-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/10 via-background/0 to-background/40" />
          <div className="relative container mx-auto h-full px-4 flex items-center justify-end">
            <div className="max-w-xl text-right md:pr-8">
              <p className="text-sm uppercase tracking-[0.3em] text-primary/90">
                New Bridal Collection
              </p>
              <h1 className="mt-3 font-serif text-4xl md:text-6xl leading-tight text-primary">
                Gorgeous designs that<br /> perfectly express your<br /> romantic stories
              </h1>
              <p className="mt-5 text-base text-foreground/80">
                Queen of love, where joy is woven and where every embrace tells a story.
                Handcrafted silks, intricate zari, and timeless silhouettes for the
                modern bride.
              </p>
              <div className="mt-7 flex justify-end gap-3">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-none px-8">
                  Shop Now <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Promo tiles row */}
        <div className="container mx-auto px-4 -mt-6 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: "MEGA SALE", title: "70%", sub: "Off", img: catSaree },
              { label: "EXCLUSIVE DESIGNER", title: "50%", sub: "Off", img: catChoiAlt() },
              { label: "MODERN STYLE", title: "Sale 50%", sub: "Limited", img: catBridal },
            ].map((p, i) => (
              <div
                key={i}
                className="relative h-32 md:h-36 overflow-hidden rounded-md group"
                style={{ backgroundImage: `url(${p.img})`, backgroundSize: "cover", backgroundPosition: "center" }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-primary/70 to-primary/20" />
                <div className="relative h-full flex flex-col justify-center px-6 text-primary-foreground">
                  <span className="text-[10px] tracking-[0.25em] opacity-90">{p.label}</span>
                  <span className="font-serif text-3xl md:text-4xl">{p.title}</span>
                  <span className="text-xs uppercase tracking-widest opacity-80">{p.sub}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Category marquee strip */}
      <section className="mt-10 bg-primary text-primary-foreground py-5 overflow-hidden">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...categories, ...categories, ...categories].map((c, i) => (
            <span key={i} className="font-serif text-2xl md:text-3xl px-8 flex items-center gap-8">
              {c}
              <span className="text-accent">✦</span>
            </span>
          ))}
        </div>
      </section>

      {/* Enhance Your Look — products */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center">
          <Sparkles className="mx-auto h-5 w-5 text-accent" />
          <h2 className="mt-2 font-serif text-4xl md:text-5xl text-foreground">
            Enhance Your Look
          </h2>
          <p className="mt-3 max-w-xl mx-auto text-sm text-muted-foreground">
            Curated pieces handpicked by our stylists — wear them to weddings,
            festivals, or whenever the moment calls for magic.
          </p>
        </div>

        <div className="mt-10">
          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="aspect-[3/4] bg-secondary/40 rounded-md animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <EmptyProducts />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {products.slice(0, 4).map((p) => (
                <ProductCard key={p.node.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Banner couple */}
      <section className="relative">
        <div className="relative h-[420px] w-full overflow-hidden">
          <img
            src={bannerCouple}
            alt="Bride and groom under chandelier"
            width={1920}
            height={1080}
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30" />
          <div className="absolute inset-x-0 bottom-6 flex flex-wrap justify-center gap-3 px-4">
            <Pill>Crafted In The Soul Of Every Weave</Pill>
            <Pill>Find Elegant Designs</Pill>
            <Pill>We Customize The Design To Your Liking</Pill>
          </div>
        </div>
      </section>

      {/* Find The Perfect Outfit */}
      <section id="collections" className="container mx-auto px-4 py-16">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div>
            <h2 className="font-serif text-4xl md:text-5xl text-foreground">
              Find The Perfect Outfit For You
            </h2>
            <p className="mt-3 max-w-xl text-sm text-muted-foreground">
              From everyday drapes to once-in-a-lifetime bridal looks — explore
              our most loved silhouettes.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {["Silk", "Net", "Cotton", "Velvet"].map((t) => (
              <span
                key={t}
                className="px-4 py-2 rounded-full border border-primary/30 text-sm text-primary hover:bg-primary hover:text-primary-foreground transition cursor-pointer"
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-10">
          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="aspect-[3/4] bg-secondary/40 rounded-md animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? null : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {products.slice(4, 8).map((p) => (
                <ProductCard key={p.node.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Trust strip */}
      <section className="bg-secondary/50 border-y border-border">
        <div className="container mx-auto px-4 py-10 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { icon: Truck, t: "Free Shipping", s: "Orders above ₹2999" },
            { icon: ShieldCheck, t: "Secure Payment", s: "100% protected" },
            { icon: RotateCcw, t: "Easy Returns", s: "7-day return policy" },
            { icon: Sparkles, t: "Handcrafted", s: "By master artisans" },
          ].map(({ icon: Icon, t, s }, i) => (
            <div key={i} className="flex flex-col items-center gap-2">
              <Icon className="h-6 w-6 text-primary" />
              <div className="font-serif text-lg">{t}</div>
              <div className="text-xs text-muted-foreground">{s}</div>
            </div>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

function catChoiAlt() {
  return catCholi;
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="bg-background/95 text-foreground rounded-full px-5 py-2 text-sm font-medium shadow-sm border border-border">
      {children}
    </span>
  );
}

function EmptyProducts() {
  return (
    <div className="text-center py-12 border border-dashed border-border rounded-md">
      <h3 className="font-serif text-2xl text-foreground">No products found</h3>
      <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
        Your store doesn't have any products yet. Tell me in chat what product
        to add — its name, price, and a short description — and I'll create it
        in your Shopify store.
      </p>
    </div>
  );
}

// Reference cat images so Vite doesn't tree-shake them
void catLehenga;
